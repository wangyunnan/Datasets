import time
from easydict import EasyDict

C = EasyDict()
config = C

"""Save Seting"""
C.time = time.strftime("%Y%m%d_%Hh%Mm%Ss", time.localtime())
C.save_root = './save'
C.log_iter = 50

"""Dataset Setting"""
C.gtav_root = '/dssg/home/acct-eefqf/eefqf-wyn/datasets/GTAV'
C.city_root = '/dssg/home/acct-eefqf/eefqf-wyn/datasets/Cityscapes'

C.gtav_train_list = './datasets/gtav/list/train.txt'
C.city_train_list = './datasets/cityscapes/list/train.txt'
C.city_eval_list = './datasets/cityscapes/list/val.txt'

"""Image Setting"""
C.num_classes = 19
C.ignore_label = 255
C.crop_size = (1024,512)
C.scale_range = (0.55, 1.0)
C.gta_mode = 'translation' # images translation fusion

"""Train Setting"""
C.lr = 2.5e-4
C.lr_policy = 'poly' #constant poly
C.lr_power = 0.9
C.momentum = 0.9
C.weight_decay = 5e-4
C.batch_size = 2
C.num_iters = 200000
C.iters_per_epoch = 5000
C.num_epochs = 24
C.num_workers = 8
C.adabn = False
C.source_criterion = 'labeledkd' #ohemce smoothingce ce weightce weightedce
C.target_criterion = 'wnce' #ce entropyce weightentropyce slideweightentropyce wnce weightedcekd
C.source_weight_path = './save/weights/gtav_trainval_fine_weight.pth'
C.target_weight_path = './save/weights/city_train_pseudo_weight_wo_at.pth'
C.ckpt_path = './save/ckpt/Deeplabv2_gtav_sourceonly_1024_512_bs_4_crop_weightedce_epoch_12_47_3982.pth'
C.net_momentum_param = 0.99
C.net_momentum_iters = 100
C.alpha = 0.9
C.cutmix = True
C.affine = True
C.version = "nce*0.1 + rce * 1"

"""Eval Setting"""
C.eval_flip = False  # True if use the ms_flip strategy


if __name__ == '__main__':
    pass

