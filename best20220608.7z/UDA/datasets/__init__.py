from .cityscapes import Cityscapes
from .gtav import GTAV

__all__ = ['Cityscapes','GTAV']
