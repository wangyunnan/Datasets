from .cityscapes import Cityscapes

__all__ = ['Cityscapes']