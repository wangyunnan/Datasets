import os
import os.path as osp

import cv2
import numpy as np
import random

list_path = '..\\list\\train.txt'
root = 'F:\\datasets\\Cityscapes'

def get_list():
    with open(list_path, 'r') as fr:
        files = fr.readlines()
    random.shuffle(files)

    files = files[:80]
    print(len(files))
    with open('train80.txt', 'w') as f:
        for line in files:
            f.writelines(line)
            print(line)



if __name__ == '__main__':
    get_list()

#
#
# list = [20, 16, 10, 5]
#
# print(list)
#
# random.shuffle(list)
# print(list)