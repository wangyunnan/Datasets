from PIL import Image
import numpy as np
import os.path as osp
import torch
from torch.utils.data import Dataset

class Cityscapes(Dataset):
    def __init__(self, data_setting, mode, crop_size, file_length=None):
        super(Cityscapes, self).__init__()
        assert mode in ['train', 'val']
        self.mode = mode
        self.root = data_setting['root']
        self.train_list_path = data_setting['train_list']
        self.val_list_path = data_setting['val_list']
        self.file_length = file_length
        self.file_names = self.get_file_names()
        if self.file_length is not None:
            self.file_names = self.manage_file_names()
        self.crop_size = crop_size
        self.bgr_mean = np.array((104.00698793, 116.66876762, 122.67891434), dtype=np.float32)

    def __len__(self):
        if self.file_length is not None:
            return self.file_length
        return len(self.file_names)

    def __getitem__(self, index):
        names = self.file_names[index]
        img = Image.open(osp.join(self.root, names[0])).convert('RGB')
        gt = Image.open(osp.join(self.root, names[1]))

        # Random mirror ...

        # Resize
        img = img.resize(self.crop_size, Image.BICUBIC)
        gt = gt.resize(self.crop_size, Image.NEAREST)

        # Gaussian blur ...

        # To numpy array
        img = np.asarray(img, np.float32)
        gt = np.asarray(gt, np.float32)

        # Normalize
        img = img[:, :, ::-1]  # change to BGR
        img = img - self.bgr_mean
        img = img.transpose((2, 0, 1))

        # To tensor
        img = torch.from_numpy(np.ascontiguousarray(img)).float()
        gt = torch.from_numpy(np.ascontiguousarray(gt)).long()

        return img, gt

    def get_file_names(self):
        list_path = self.train_list_path if self.mode == 'train' else self.val_list_path
        file_names = []
        with open(list_path, 'r') as fr:
            files = fr.readlines()
        for item in files:
            img_name, gt_name = item.strip().split('\t')
            file_names.append([img_name, gt_name])

        return file_names

    def manage_file_names(self):
        assert isinstance(self.file_length, int)
        dataset_length = len(self.file_names)
        file_names_per_epoch = self.file_names * (self.file_length // dataset_length)

        rand_indices = torch.randperm(dataset_length).tolist()
        new_indices = rand_indices[:self.file_length % dataset_length]
        file_names_per_epoch += [self.file_names[i] for i in new_indices]

        return file_names_per_epoch

if __name__ == '__main__':
    print('In cityscapes')

    data_setting = {'root': '',
                    'train_list': './list/train.txt',
                    'val_list': './list/val.txt'}

    ds = Cityscapes(data_setting, 'train', None)
    print(ds.__len__())
    print(16000 // 2975)
