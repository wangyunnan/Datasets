import os.path as osp
if __name__ == '__main__':

    list_path = './train_game_9K.txt'
    with open(list_path, 'r') as fr:
        files = fr.readlines()

    file_names = []
    with open('train_9k.txt', 'w') as f:
        for i, item in enumerate(files):
            img_name, gt_name = item.strip().split(' ')

            img_name = img_name.replace('game/images/', 'images/')
            gt_name = gt_name.replace('game/labels_cs/', 'labels/')
            gt_name = gt_name.replace('.png', '_trainIds.png')

            line = (img_name + '\t' + gt_name + '\n')
            f.writelines(line)
            print("Done:", i)