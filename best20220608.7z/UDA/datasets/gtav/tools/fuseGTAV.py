import cv2
import os.path as osp
import numpy as np
import random

color_map = {0: [128, 64, 128], 1: [244, 35, 232], 2: [70, 70, 70], 3: [102, 102, 156],
             4: [190, 153, 153], 5: [153, 153, 153], 6: [250, 170, 30], 7: [220, 220, 0],
             8: [107, 142, 35], 9: [152, 251, 152], 10: [70, 130, 180], 11: [220, 20, 60],
             12: [255, 0, 0], 13: [0, 0, 142], 14: [0, 0, 70], 15: [0, 60, 100], 16: [0, 80, 100],
             17: [0, 0, 230], 18: [119, 11, 32], 19: [0, 0, 0]}

#Cityscapes/GTAV Class Name List
name_list = {0: 'road', 1: 'sidewalk', 2: 'building', 3: 'wall', 4: 'fence', 5: 'pole',
             6: 'traffic light', 7: 'traffic sign', 8: 'vegetation', 9: 'terrain',
             10: 'sky', 11: 'person', 12: 'rider', 13: 'car', 14: 'truck', 15: 'bus',
             16: 'train', 17: 'motorcycle', 18: 'bicycle'}

def find_all_color_block(img, lb, nun_classes):
    for i in range(nun_classes):
        mask = lb.copy()
        index = (mask == i)
        mask[np.logical_not(index)] = 0
        mask[index] = 1
        #img, contours, hierarchy = cv2.findContours(img,cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        mask, contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        img=cv2.drawContours(img,contours,-1,color_map[i],2)

    cv2.imshow('block', img)
    cv2.waitKey()

def find_specific_color_block(img, lb, n):
    mask = lb.copy()
    index = (mask == n)
    mask[np.logical_not(index)] = 0
    mask[index] = 1
    #img, contours, hierarchy = cv2.findContours(img,cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    mask, contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    img=cv2.drawContours(img,contours,-1,(0,0,255),10)

    return img

def replace_stuff(origin, style, gt, save_path):
    origin = cv2.resize(origin, (1280, 720), interpolation=cv2.INTER_LINEAR)
    style = cv2.resize(style, (1280, 720), interpolation=cv2.INTER_LINEAR)
    gt = cv2.resize(gt, (1280, 720), interpolation=cv2.INTER_NEAREST)

    mask = gt.copy()
    img_fuse = origin.copy()
    index = (mask == 13) | (mask == 14) | (mask == 15) | (mask == 16)
    print(np.sum(index))
    img_fuse[index] = style[index]

    #img_trans = find_specific_color_block(img_trans, gt, 15)
    #img_origin = find_specific_color_block(origin, gt, 15)

    #cv2.imshow('origin', img_origin)
    #cv2.imshow('replace', img_trans)
    #cv2.waitKey()

    #cv2.imshow('fuse', img_fuse)
    #cv2.waitKey()
    #cv2.imwrite(save_path, img_fuse)

def random_replace(origin, style, gt, save_path):
    origin = cv2.resize(origin, (1280, 720), interpolation=cv2.INTER_LINEAR)
    style = cv2.resize(style, (1280, 720), interpolation=cv2.INTER_LINEAR)
    gt = cv2.resize(gt, (1280, 720), interpolation=cv2.INTER_NEAREST)

    mask = gt.copy()
    img_fuse = origin.copy()
    index = np.full((720, 1280), False)

    class_list = list(range(19))
    random.shuffle(class_list)

    for i in class_list:
        index = index | (mask == i)
        if np.sum(index) > 1280 * 720 / 2:
            break

    img_fuse[index] = style[index]

    #img_trans = find_specific_color_block(img_trans, gt, 15)
    #img_origin = find_specific_color_block(origin, gt, 15)

    #cv2.imshow('origin', img_origin)
    #cv2.imshow('replace', img_trans)
    #cv2.waitKey()

    cv2.imshow('fuse', img_fuse)
    cv2.waitKey()
    #cv2.imwrite(save_path, img_fuse)

if __name__ == '__main__':
    root = '/media/wangyunnan/Data/datasets/Cityscapes'
    list_path = '../list/train.txt'

    gta_root = '/media/wangyunnan/Data/datasets/GTAV'

    with open(list_path, 'r') as fr:
        files = fr.readlines()

    file_names = []
    for i, item in enumerate(files):
        img_name, gt_name = item.strip().split('\t')
        origin_path = osp.join(gta_root, img_name)
        trans_path = osp.join(gta_root, img_name.replace('images','translation'))
        label_path = osp.join(gta_root,  gt_name)

        origin_img = cv2.imread(origin_path)
        trans_img = cv2.imread(trans_path)
        label_img = cv2.imread(label_path, cv2.IMREAD_GRAYSCALE)

        random_replace(origin_img, trans_img, label_img, origin_path.replace('images', 'fuse'))
        print("Done:", i)