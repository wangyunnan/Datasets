import os
import os.path as osp

import cv2
import numpy as np

list_path = '..\\list\\list.txt'
root = 'F:\\datasets\\GTAV'

def get_freq():
    with open(list_path, 'r') as fr:
        files = fr.readlines()

    files_names = [item.strip().split('\t')[1] for item in files]

    freq = np.zeros(19, dtype=np.longlong)
    for idx, name in enumerate(files_names):
        print(idx)
        lbl = cv2.imread(osp.join(root, name), cv2.IMREAD_GRAYSCALE)
        mask = (lbl >= 0) & (lbl < 19)
        lbl = lbl[mask].astype('int')
        freq += np.bincount(lbl, minlength=19)

    print(freq)

def get_weight():
    freq = np.array(
        [
            16099193283, 4155428633, 8478285320, 925367586, 317481282,
            531401266, 67288808, 40463971, 3810296251, 1074861777,
            6784666433, 181828023, 15321782, 1259269812, 564950248,
            184638969, 32522117, 15799033, 2718199
        ]
    )
    radio = freq / freq.sum()
    print(radio * 100)# 0 1 2 10
    print(radio[9] * 100)

    # freq = np.array(
    #     [
    #         8257583107, 1933668568, 3695583643, 474343859, 196878855,
    #         284976430, 32017868, 23593840, 1744115482, 570311206,
    #         3692876973, 84170997, 7145664, 611176486, 286814250,
    #         115366961, 28849798, 7544736, 1567045
    #     ]
    # )



    # [0.6254756  0.91231251 0.83238672 0.97848355 0.99107175 0.98707622
    #  0.99854793 0.99893004 0.92090452 0.97413724 0.83252368 0.9961591
    #  0.99967596 0.97227618 0.98699205 0.99476843 0.99869174 0.99965783
    #  0.99992894]

    weight = 1 -(freq / freq.sum())
    weight = weight/ weight.sum()
    print(weight)

    normedWeights = [1 - (x / sum(freq)) for x in freq]
    normedWeights = np.asarray(normedWeights)
    normedWeights = normedWeights / normedWeights.sum()
    print(normedWeights)

    # [1.14367487e-04 4.88478057e-04 2.55549043e-04 1.99072914e-03
    #  4.79751777e-03 3.31430957e-03 2.94981984e-02 4.00325589e-02
    #  5.41540609e-04 1.65618110e-03 2.55758030e-04 1.11519332e-02
    #  1.32187176e-01 1.54500405e-03 3.29286540e-03 8.18748397e-03
    #  3.27407888e-02 1.25181201e-01 6.02768359e-01]
    weight = 1.0 / freq
    weight = weight/ weight.sum()
    print(weight)

    # [1.00000000e+00 4.27112695e+00 2.23445534e+00 1.74064255e+01
    #  4.19482659e+01 2.89794736e+01 2.57924687e+02 3.50034436e+02
    #  4.73509231e+00 1.44812231e+01 2.23628268e+00 9.75096465e+01
    #  1.15581079e+03 1.35091195e+01 2.87919712e+01 7.15892617e+01
    #  2.86277067e+02 1.09455234e+03 5.27045207e+03]
    weight = np.max(freq) / freq
    weight = weight / weight.sum()
    print(weight)

if __name__ == '__main__':
    get_weight()


# train
# [8257583107 1933668568 3695583643  474343859  196878855  284976430
# #    32017868   23593840 1744115482  570311206 3692876973   84170997
# #     7145664  611176486  286814250  115366961   28849798    7544736
# #     1567045]

# all
# [16099193283  4155428633  8478285320   925367586   317481282   531401266
#     67288808    40463971  3810296251  1074861777  6784666433   181828023
#     15321782  1259269812   564950248   184638969    32522117    15799033
#      2718199]

