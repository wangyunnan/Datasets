import scipy.io as sio
from os import path as osp

#load
data = sio.loadmat('split.mat')
print(data['trainIds'].shape)
print(data['valIds'].shape)
print(data['testIds'].shape)

with open('train.txt', 'w') as f:
    for idx in data['trainIds']:
        name = '%05d.png' % idx
        imgPath = osp.join('images/', name)
        labPath = osp.join('labels/', name.replace('.png', '_trainIds.png'))
        line = (imgPath + '\t' + labPath + '\n')
        f.writelines(line)
        print(line)

with open('val.txt', 'w') as f:
    for idx in data['valIds']:
        name = '%05d.png' % idx
        imgPath = osp.join('images/', name)
        labPath = osp.join('labels/', name.replace('.png', '_trainIds.png'))
        line = (imgPath + '\t' + labPath + '\n')
        f.writelines(line)
        print(line)

with open('test.txt', 'w') as f:
    for idx in data['testIds']:
        name = '%05d.png' % idx
        imgPath = osp.join('images/', name)
        labPath = osp.join('labels/', name.replace('.png', '_trainIds.png'))
        line = (imgPath + '\t' + labPath + '\n')
        f.writelines(line)
        print(line)
