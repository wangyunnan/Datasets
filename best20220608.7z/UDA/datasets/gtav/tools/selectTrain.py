import cv2
import os.path as osp
import os
import numpy as np
import random

if __name__ == '__main__':
    root = '/media/wangyunnan/Data/datasets/Cityscapes'
    list_path = '../list/train.txt'

    gta_root = '/media/wangyunnan/Data/datasets/GTAV'

    with open(list_path, 'r') as fr:
        files = fr.readlines()

    file_names = []
    for i, item in enumerate(files):
        img_name, gt_name = item.strip().split('\t')
        trans_path = osp.join(gta_root, img_name.replace('images','choose'))
        if osp.exists(trans_path):
            trans_img = cv2.imread(trans_path)
            os.remove(trans_path)
            cv2.imwrite(trans_path.replace('choose','temp'), trans_img)
            print("Done:", i)