import torch

class Optimizer(object):
    def __init__(self,
                params,
                base_lr,
                momentum,
                weight_decay,
                current_iter,
                total_iter,
                lr_power,
                policy,
                *args, **kwargs):

        self.base_lr = base_lr
        self.lr = self.base_lr
        self.total_iters = float(total_iter)
        self.lr_power = lr_power
        self.iter = float(current_iter)
        self.policy = policy

        self.optim = torch.optim.SGD(
                params,
                lr = self.lr,
                momentum = momentum,
                weight_decay = weight_decay
        )

    def get_lr(self):
        factor = (1.0 - self.iter / self.total_iters) ** self.lr_power
        lr = self.base_lr * factor
        return lr

    def step(self):
        if self.policy == 'poly':
            self.lr = self.get_lr()
        self.optim.param_groups[0]['lr'] = self.lr
        self.optim.param_groups[1]['lr'] = self.lr * 10
        self.iter += 1
        self.optim.step()

    def zero_grad(self):
        self.optim.zero_grad()

