import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class CriterionOhemCE(nn.Module):
    def __init__(self, thresh, min_kept, ignore_index=255):
        super(CriterionOhemCE, self).__init__()
        self.thresh = -torch.log(torch.tensor(thresh, dtype=torch.float)).cuda()
        self.min_kept = min_kept
        self.ignore_lb = ignore_index
        self.criterion = nn.CrossEntropyLoss(ignore_index=ignore_index, reduction='none')

    def forward(self, logits, labels):
        loss = self.criterion(logits, labels).view(-1)
        loss, _ = torch.sort(loss, descending=True)
        if loss[self.min_kept] > self.thresh:
            loss = loss[loss>self.thresh]
        else:
            loss = loss[:self.min_kept]
        return torch.mean(loss)

class CriterionL2KD(nn.Module):
    def __init__(self, reduction='mean'):
        super(CriterionL2KD, self).__init__()
        assert reduction in ['none', 'mean', 'sum']
        self.reduction = reduction
        self.criterion = nn.MSELoss(reduction='none')

    def forward(self, logits_S, logits_T):
        assert logits_S.shape == logits_T.shape
        loss = self.criterion(logits_S, logits_T)
        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        return loss

class CriterionOhemL2KD(nn.Module):
    def __init__(self, thresh, min_kept):
        super(CriterionOhemL2KD, self).__init__()
        self.thresh = -torch.log(torch.tensor(thresh, dtype=torch.float)).cuda()
        self.min_kept = min_kept
        self.criterion = CriterionL2KD(reduction='none')

    def forward(self, logits_S, logits_T, temperature):
        loss = self.criterion(logits_S, logits_T, temperature).view(-1)
        loss, _ = torch.sort(loss, descending=True)
        if loss[self.min_kept] > self.thresh:
            loss = loss[loss>self.thresh]
        else:
            loss = loss[:self.min_kept]
        return torch.mean(loss)

class CriterionCEKD(nn.Module):
    def __init__(self, reduction='mean'):
        super(CriterionCEKD, self).__init__()
        assert reduction in ['none', 'mean', 'sum']
        self.reduction = reduction

    def forward(self, logits_S, logits_T):
        assert logits_S.shape == logits_T.shape
        probs_T = -1.0 * F.softmax(logits_T, dim=1)
        #probs_T = -1.0 * logits_T # for debug !!!
        logprobs_S = F.log_softmax(logits_S, dim=1)
        loss = torch.mul(probs_T, logprobs_S).sum(dim=1)
        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        return loss

class CriterionOhemCEKD(nn.Module):
    def __init__(self, thresh, min_kept):
        super(CriterionOhemCEKD, self).__init__()
        self.thresh = -torch.log(torch.tensor(thresh, dtype=torch.float)).cuda()
        self.min_kept = min_kept
        self.criterion = CriterionCEKD(reduction='none')

    def forward(self, logits_S, logits_T, temperature):
        loss = self.criterion(logits_S, logits_T, temperature).view(-1)
        loss, _ = torch.sort(loss, descending=True)
        if loss[self.min_kept] > self.thresh:
            loss = loss[loss>self.thresh]
        else:
            loss = loss[:self.min_kept]
        return torch.mean(loss)

class CriterionThresholdKd(nn.Module):
    def __init__(self):
        super(CriterionThresholdKd, self).__init__()
        self.criterion = CriterionCEKD(reduction='none')

    def forward(self, logits_S, logits_T, threshold, temperature):
        assert logits_S.shape == logits_T.shape
        probs_T = F.softmax(logits_T, dim=1)
        maxpred, argpred = torch.max(probs_T.detach(), dim=1)
        mask = (maxpred > threshold).float()
        loss = self.criterion(logits_S, logits_T, temperature)
        loss = loss * mask
        return loss.sum() / mask.sum()

class CriterionSmoothingCE(nn.Module):
    def __init__(self):
        super(CriterionSmoothingCE, self).__init__()

    def forward(self, logits, labels, smoothing=0.1):
        C = logits.shape[1]
        mask = (labels < C).float()
        confidence = 1. - smoothing
        logprobs = F.log_softmax(logits, dim=1)
        #logprobs = logits.log() # for debug!!!
        labels = labels.float() * mask
        nll_loss = -logprobs.gather(dim=1, index=labels.unsqueeze(1).long())
        nll_loss = nll_loss.squeeze(1)
        smooth_loss = (-logprobs.sum(dim=1) - nll_loss ) / (C - 1)
        loss = confidence * nll_loss + smoothing * smooth_loss
        loss = loss * mask
        return loss.sum() / mask.sum()

class CriterionFocalSmoothingCE(nn.Module):
    def __init__(self):
        super(CriterionFocalSmoothingCE, self).__init__()
        self.weight = torch.tensor([
            0.59204979, 0.92927596, 0.82157756, 0.97924144, 0.99395318, 0.98767773,
            0.99855976, 0.99901842, 0.91780826, 0.9747173, 0.84800641, 0.99702588,
            0.99975471, 0.97768237, 0.98875159, 0.9966383, 0.9986023, 0.99971024,
            0.99994882]).cuda()

    def forward(self, logits, labels, smoothing=0.1):
        C = logits.shape[1]
        mask = (labels < C).float()
        confidence = 1. - smoothing
        probs = F.softmax(logits, dim=1)
        logprobs = F.log_softmax(logits, dim=1)
        #logprobs = logits.log() # for debug!!!
        labels = labels.float() * mask
        nll_loss = -logprobs.gather(dim=1, index=labels.unsqueeze(1).long())
        nll_loss = nll_loss.squeeze(1)
        correct_probs = probs.gather(dim=1, index=labels.unsqueeze(1).long())
        correct_probs = correct_probs.squeeze(1)
        #smooth_loss = (-logprobs.sum(dim=1) - nll_loss ) / (C - 1)
        average_prob = smoothing / (C - 1)
        smooth_loss = (-((average_prob - probs) * (average_prob - probs) * logprobs).sum(dim=1) -
                       (average_prob - correct_probs) * (average_prob - correct_probs)* nll_loss)
        #loss = confidence * nll_loss * (confidence - correct_probs) * (confidence - correct_probs) + smoothing * smooth_loss
        #loss = (confidence * nll_loss + smoothing * smooth_loss) * self.weight[labels.long()] * (1. - correct_probs)* (1. - correct_probs)
        loss = (confidence * (confidence - correct_probs) * (confidence - correct_probs) * nll_loss +
                average_prob * smooth_loss) * self.weight[labels.long()]

        loss = loss * mask
        return loss.sum() / mask.sum()

class CriterionWeightedCE(nn.Module):
    def __init__(self, weight, ignore_index):
        super(CriterionWeightedCE, self).__init__()
        self.weight = weight
        self.criterion = nn.CrossEntropyLoss(weight=self.weight, ignore_index=ignore_index, reduction='mean')

    def forward(self, logits, labels):
        loss = self.criterion(logits, labels)
        return loss

class CriterionWeightedCEKD(nn.Module):
    def __init__(self, weight):
        super(CriterionWeightedCEKD, self).__init__()
        self.weight = weight
        self.criterion = CriterionCEKD(reduction='none')

    def forward(self, logits_S, logits_T):
        assert logits_S.shape == logits_T.shape
        probs = F.softmax(logits_T, dim=1)
        maxpred, labels = torch.max(probs.detach(), dim=1)
        loss = self.criterion(logits_S, logits_T)
        weight = self.weight[labels.long()]
        loss = loss * weight
        loss = loss.sum() / weight.sum()
        return loss

class CriterionWeightSmoothingCE(nn.Module):
    def __init__(self):
        super(CriterionWeightSmoothingCE, self).__init__()
        self.weight = torch.tensor([
            0.6254756,  0.91231251, 0.83238672, 0.97848355, 0.99107175, 0.98707622,
            0.99854793, 0.99893004, 0.92090452, 0.97413724, 0.83252368, 0.9961591,
            0.99967596, 0.97227618, 0.98699205, 0.99476843, 0.99869174, 0.99965783,
            0.99992894]).cuda()

    def forward(self, logits, labels, smoothing=0.1):
        C = logits.shape[1]
        mask = (labels < C).float()
        confidence = 1. - smoothing
        logprobs = F.log_softmax(logits, dim=1)
        #logprobs = logits.log() # for debug!!!
        labels = labels.float() * mask
        nll_loss = -logprobs.gather(dim=1, index=labels.unsqueeze(1).long())
        nll_loss = nll_loss.squeeze(1)
        smooth_loss = (-logprobs.sum(dim=1) - nll_loss ) / (C - 1)
        loss = (confidence * nll_loss  + smoothing * smooth_loss ) * self.weight[labels.long()]
        loss = loss * mask
        return loss.sum() / mask.sum()

class CriterionSA(nn.Module):
    def __init__(self, num_classes=19):
        super(CriterionSA, self).__init__()
        self.num_classes = num_classes
        self.criterion = nn.MSELoss()

    def forward(self, feat_S, feat_T, label_S, label_T):
        mask_S = F.interpolate(label_S.unsqueeze(1).float(), size=feat_S.size()[2:], mode='nearest').expand(feat_S.size())
        mask_T = F.interpolate(label_T.unsqueeze(1).float(), size=feat_T.size()[2:], mode='nearest').expand(feat_T.size())

        represent_S = torch.zeros(feat_S.size()[0], self.num_classes, self.num_classes, requires_grad=True)
        represent_T = torch.zeros(feat_T.size()[0], self.num_classes, self.num_classes, requires_grad=True)
        class_mask = torch.arange(self.num_classes).expand(represent_S.size())

        for i in range(self.num_classes):
            if (not (mask_S == i).sum() == 0) and (not (mask_T == i).sum() == 0):
                selected_mask_S = (mask_S == i).float()
                selected_mask_T = (mask_T == i).float()
                selected_class = (class_mask == i).float()

                represent_Si = ((selected_mask_S * feat_S).sum(-1).sum(-1) / (selected_mask_S.sum(-1).sum(-1) + 1e-6))
                represent_S = represent_S + represent_Si.view(self.num_classes, 1) * selected_class
                represent_Ti = ((selected_mask_T * feat_T).sum(-1).sum(-1) / (selected_mask_T.sum(-1).sum(-1) + 1e-6))
                represent_T = represent_T + represent_Ti.view(self.num_classes, 1) * selected_class

        loss = self.criterion(represent_S, represent_T)
        return loss

class CriterionSA2(nn.Module):
    def __init__(self, num_classes=19):
        super(CriterionSA2, self).__init__()
        self.num_classes = num_classes
        self.criterion = nn.MSELoss()

    def forward(self, feats_S, feats_T, labels_S, logits_T, threshold):
        """
        :param feats_S: features of source image
        :param feats_T: features of target image
        :param labels_S: labels of source image
        :param logits_T: logits of target image predicted by pretrained (teacher) model
        :param threshold: theshold of logits, which can generate labels of target image
        """
        N, C, _, _ = feats_S.shape
        probs = F.softmax(logits_T, dim=1)
        maxpred, labels_T = torch.max(probs.detach(), dim=1)
        labels_T[maxpred < threshold] = C
        mask_T = F.interpolate(labels_T.unsqueeze(1).float(), size=feats_T.size()[2:], mode='nearest').expand(feats_T.size())
        mask_S = F.interpolate(labels_S.unsqueeze(1).float(), size=feats_S.size()[2:], mode='nearest').expand(feats_S.size())

        losses = []
        for i in range(self.num_classes):
            if (not (mask_S == i).sum() == 0) and (not (mask_T == i).sum() == 0):
                selected_mask_S = (mask_S == i).float()
                selected_mask_T = (mask_T == i).float()

                represent_Si = ((selected_mask_S * feats_S).sum(-1).sum(-1) / selected_mask_S.sum(-1).sum(-1))
                represent_Ti = ((selected_mask_T * feats_T).sum(-1).sum(-1) / selected_mask_T.sum(-1).sum(-1))
                losses.append(self.criterion(represent_Si, represent_Ti))

        loss = losses[0]
        if len(losses) == 1:
            return loss
        else:
            for i in range(len(losses) - 1):
                loss = loss + losses[i+1]
        return loss / len(losses)

class CriterionNeutralKD(nn.Module):
    def __init__(self, reduction):
        super(CriterionNeutralKD, self).__init__()
        assert reduction in ['none', 'mean', 'sum']
        self.criterion = nn.KLDivLoss(reduction='none')
        self.reduction = reduction

    def forward(self, logits_S, logits_T):
        """
        :param logits_S: logits predicted by student
        :param logits_T: logits predicted by teacher
        :param threshold: theshold of logits
        """
        assert logits_S.shape == logits_T.shape
        probs_S = F.softmax(logits_S, dim=1)
        entropy = -1.0 * probs_S * F.log_softmax(logits_S, dim=1)
        kl_loss = self.criterion(F.log_softmax(logits_S, dim=1), F.softmax(logits_T, dim=1))
        loss = entropy.sum(1) + kl_loss.sum(1)

        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        return loss

class CriterionWeightNeutralKD(nn.Module):
    def __init__(self, weight):
        super(CriterionWeightNeutralKD, self).__init__()
        self.criterion = CriterionNeutralKD(reduction='none')
        self.weight = weight

    def forward(self, logits_S, logits_T, mask):
        """
        :param logits_S: logits predicted by student
        :param logits_T: logits predicted by teacher
        :param threshold: theshold of logits
        """
        assert logits_S.shape == logits_T.shape
        mask = mask.float()
        probs_T = F.softmax(logits_T, dim=1)
        maxpred, labels = torch.max(probs_T.detach(), dim=1)
        assert mask.shape == labels.shape
        loss = self.criterion(logits_S, logits_T)
        weight = self.weight[labels.long()]
        loss = loss * weight
        loss = (loss * mask).sum() / (weight * mask).sum()
        return loss

class CriterionWeightNeutralKD2(nn.Module):
    def __init__(self, decay=0.99):
        super(CriterionWeightNeutralKD2, self).__init__()
        self.criterion = nn.KLDivLoss(reduction='none')
        self.decay = decay
        self.weight = torch.tensor([
            3.7452440e-01, 8.7687490e-02, 1.6761328e-01, 2.1516450e-02, 8.9282500e-03,
            1.2923780e-02, 1.4520700e-03, 1.0699600e-03, 7.9095480e-02, 2.5862760e-02,
            1.6747632e-01, 3.8409000e-03, 3.2404000e-04, 2.7723820e-02, 1.3007950e-02,
            5.2315700e-03, 1.3082600e-03, 3.4217000e-04, 7.1060000e-05]).cuda()

    def forward(self, logits_S, logits_T, threshold, temperature):
        """
        :param logits_S: logits predicted by student
        :param logits_T: logits predicted by teacher
        :param threshold: theshold of logits
        """
        assert logits_S.shape == logits_T.shape
        probs_T = F.softmax(logits_T, dim=1)
        maxpred, labels = torch.max(probs_T.detach(), dim=1)
        mask = (maxpred > threshold)

        freq = torch.bincount(labels[mask], minlength=19).float().cuda()
        weight_new = freq / freq.sum()
        self.weight = self.weight * self.decay + (1.0 - self.decay) * weight_new

        mask = mask.float()
        probs_S = F.softmax(logits_S / temperature, dim=1).clamp(min=1e-6,max=1.0)
        entropy = -1.0 * probs_S * torch.log(probs_S)
        kl_loss = self.criterion(F.log_softmax(logits_S / temperature, dim=1), F.softmax(logits_T / temperature, dim=1))
        loss = entropy.sum(1) + kl_loss.sum(1)
        loss = loss * (1 - self.weight)[labels.long()]
        loss = loss * mask
        return loss.sum() / mask.sum()

class CriterionSDD(nn.Module):
    def __init__(self):
        super(CriterionSDD, self).__init__()
        self.criterion = nn.CrossEntropyLoss(ignore_index=255)

    def forward(self, logits, labels):
        loss = self.criterion(logits, labels)
        return loss

class CriterionEntropy(nn.Module):
    def __init__(self):
        super(CriterionEntropy, self).__init__()

    def forward(self, logits):
        probs = F.softmax(logits, dim=1).clamp(min=1e-6, max=1.0)

        entropy = -1.0 * probs * torch.log(probs)
        loss = entropy.sum(1)
        return loss.mean()

class CriterionADV(nn.Module):
    def __init__(self):
        super(CriterionADV, self).__init__()

    def forward(self, logits, threshold=0.8):
        probs = F.softmax(logits, dim=1).clamp(min=1e-6, max=1.0)
        maxpred, labels = torch.max(probs.detach(), dim=1)
        mask = (maxpred < threshold).float()
        entropy = -1.0 * probs * torch.log(probs)
        loss = entropy.sum(1)
        loss = loss * mask
        return loss.mean()

class CriterionWeightedADV(nn.Module):
    def __init__(self, weight=None):
        super(CriterionWeightedADV, self).__init__()
        self.weight = weight

    def forward(self, logits, threshold=0.8):
        probs = F.softmax(logits, dim=1)
        maxpred, labels = torch.max(probs.detach(), dim=1)
        mask = (maxpred < threshold).float()
        entropy = -1.0 * F.softmax(logits / 0.5, dim=1) * F.log_softmax(logits / 0.5, dim=1)#
        loss = entropy.sum(1)#
        weight = self.weight[labels.long()]
        loss = loss * weight
        loss = (loss * mask).sum() / (weight * mask).sum()
        return loss

class CriterionWeightedMaxsquare(nn.Module):
    def __init__(self, weight=None):
        super(CriterionWeightedMaxsquare, self).__init__()
        self.weight = weight

    def forward(self, logits, threshold=0.8):
        probs = F.softmax(logits, dim=1)
        maxpred, labels = torch.max(probs.detach(), dim=1)
        mask = (maxpred < threshold).float()
        loss = -0.5 * torch.pow(probs, 2).sum(1)#
        weight = self.weight[labels.long()]
        loss = loss * weight
        loss = (loss * mask).sum() / (weight * mask).sum()
        return loss

class CriterionWeightedStructure(nn.Module):
    def __init__(self, weight=None):
        super(CriterionWeightedStructure, self).__init__()
        self.criterion = nn.KLDivLoss(reduction='none')
        self.weight = weight

    def forward(self, logits, smooth, mask):
        #kl_loss = self.criterion(F.log_softmax(logits, dim=1), F.softmax(smooth, dim=1))
        probs = F.softmax(logits, dim=1)
        maxpred, labels = torch.max(probs.detach(), dim=1)
        entropy = -1.0 * probs * F.log_softmax(logits, dim=1)
        loss = entropy.sum(1) #+ kl_loss.sum(1)
        weight = self.weight[labels.long()]
        #loss = loss * weight
        #loss = loss.sum() / weight.sum()
        return loss.mean()

def test_CriterionSA2():
    feats_S = np.asarray(
        [
            [[[1, 2],[3, 4]],[[5, 6],[7, 8]], [[9, 10],[11, 12]]],
            [[[13, 14],[15, 16]], [[17, 18],[19, 20]],[[21, 22],[23, 24]]]
        ]
    )
    labels_S = np.asarray(
        [
            [[0,1],[1,1]],
            [[1,0],[0,1]]
        ]
    )
    feats_S = torch.from_numpy(feats_S).float()
    labels_S = torch.from_numpy(labels_S).float()#.unsqueeze(1).expand(feats_S.size())
    print(labels_S.shape)
    N, C, _, _ = feats_S.shape
    represent_S = torch.zeros(N, C, 2, requires_grad=True)
    #out = feats_S * labels_S
    mask_S = F.interpolate(labels_S.unsqueeze(1).float(), size=feats_S.size()[2:], mode='nearest').expand(
        feats_S.size())
    print(feats_S.sum(-1).sum(-1).shape)
    print((mask_S == 1).sum(-1).sum(-1).shape)
    represent_Si = ((feats_S*mask_S).sum(-1).sum(-1) / (mask_S == 1).sum(-1).sum(-1).float())
    print(represent_Si)
    #print(out)
    selected_class_S = torch.arange(2).expand(represent_S.size())
    print(selected_class_S)

    represent_S = represent_S + represent_Si.unsqueeze(-1).expand(
        selected_class_S.size()) * (selected_class_S == 0).float()
    print(represent_S)

    loss1 = nn.MSELoss()
    loss2 = nn.MSELoss(reduction='sum')


def test_CriterionNeutralKD():
    logits_S = torch.randn(8,19,10,10)
    logits_T = torch.randn(8,19,10,10)

    criterion = CriterionNeutralKD()

    loss = criterion(logits_S, logits_T, 0.95, 1.)

    print(loss.shape)

def test_CriterionWeightSmoothingCE():
    from dataloader import get_gtav_train_loader
    from network.deeplab import DeeplabV2
    model = DeeplabV2(num_classes=19)
    model.cuda()
    model.load_state_dict(torch.load('./save/teacher_init1_447168.pth'))
    # DataLoader setting
    source_loader = get_gtav_train_loader()
    source_loader_iter = iter(source_loader)
    source_img, source_gt = next(source_loader_iter)
    source_img = source_img.cuda()
    source_gt = source_gt.cuda()

    pred,_ = model(source_img)

    criterion1 = CriterionWeightSmoothingCE()
    criterion2 = CriterionSmoothingCE()
    loss1 = criterion1(pred,source_gt)
    loss2 = criterion2(pred,source_gt)

    print(loss1)
    print(loss2)

def test_myweight():
    inputs = torch.FloatTensor([0,1,2,0,0,0,0,0,0,1,0,0.5])
    inputs = inputs.view((1,3,4))
    outputs = torch.LongTensor([0, 1,2, 2])
    outputs = outputs.view((1, 4))
    print(inputs.shape)
    print(inputs)
    weight = torch.FloatTensor([10, 200, 30000])
    ce = nn.CrossEntropyLoss(weight=weight)

    loss = ce(inputs, outputs)
    print(loss)

    ce2 = nn.CrossEntropyLoss(reduction='none')
    loss2 = ce2(inputs, outputs)
    w = weight[outputs]
    loss2 = loss2 * w
    loss2 = loss2.sum() / w.sum()
    print(loss2)

def test_maxsqure():
    prob = torch.randn(2,3,1,1)
    prob = F.softmax(prob, dim=1)
    loss = -1.0 * torch.pow(prob, 2).sum(1) * 0.5
    print(loss)
    loss = -torch.mean(loss)
    print(loss)

class CriterionWeightFuse(nn.Module):
    def __init__(self, weight, ignore_index=255):
        super(CriterionWeightFuse, self).__init__()
        self.target_criterion = CriterionNeutralKD(reduction='none')
        self.source_criterion= nn.CrossEntropyLoss(reduction='none', ignore_index=19)
        ignore = torch.FloatTensor([0]).cuda()
        self.weight = torch.cat([weight, ignore])

    def forward(self, target_out, target_soft, target_pseudo, mask):
        assert target_out.shape == target_soft.shape
        mask = mask.float()
        target_loss = self.target_criterion(target_out, target_soft)
        source_loss = self.source_criterion(target_out, target_pseudo)
        loss = target_loss * (1.0 - mask) + source_loss * mask
        weight = self.weight[target_pseudo]
        loss = loss * weight
        loss = loss.sum() / weight.sum()
        return loss

class CriterionWeightCutMix(nn.Module):
    def __init__(self, weight):
        super(CriterionWeightCutMix, self).__init__()
        self.criterion = nn.KLDivLoss(reduction='none')
        self.weight = weight

    def forward(self, logits_student, probs_teacher, mask):
        assert logits_student.shape == probs_teacher.shape
        mask = mask.float()
        maxpred, labels = torch.max(probs_teacher.detach(), dim=1)

        probs_student = F.softmax(logits_student, dim=1)
        entropy = -1.0 * probs_student * F.log_softmax(logits_student, dim=1)
        kl_loss = self.criterion(F.log_softmax(logits_student, dim=1), probs_teacher)
        loss = entropy.sum(1) + kl_loss.sum(1)

        weight = self.weight[labels]
        loss = loss * weight
        loss = (loss * mask).sum() / (weight * mask).sum()
        return loss.mean()

class CriterionSeparateCE(nn.Module):
    def __init__(self, weight, threshold=0.9):
        super(CriterionSeparateCE, self).__init__()
        self.weight = weight
        self.threshold = threshold
        self.criterion_l = CriterionNeutralKD(reduction='none')
        self.criterion_h = nn.CrossEntropyLoss(reduction='none')

    def forward(self, logits_S, labels_T, logits_T):
        loss_l = self.criterion_l(logits_S, logits_T)
        loss_h = self.criterion_h(logits_S, labels_T)
        probs = F.softmax(logits_T, dim=1)
        maxpred, _ = torch.max(probs.detach(), dim=1)
        mask = (maxpred > self.threshold).float()
        loss = mask * loss_h + (1.0 - mask) * loss_l
        weight = self.weight[labels_T.long()]
        loss = loss * weight
        loss = loss.sum() / weight.sum()
        return loss

class CriterionLabeledKD(nn.Module):
    def __init__(self, alpha, weight, ignore_index):
        super(CriterionLabeledKD, self).__init__()
        self.alpha = alpha
        self.weight = weight
        self.ignore_index = ignore_index
        self.criterion_kd = nn.KLDivLoss(reduction='none')
        self.criterion_gt = nn.CrossEntropyLoss(reduction='none', ignore_index=self.ignore_index)

    def forward(self, logits_S, labels, logits_T):
        assert logits_S.shape == logits_T.shape
        mask = (labels != self.ignore_index)
        labels[labels == self.ignore_index] = 0
        loss_kd = self.criterion_kd(F.log_softmax(logits_S, dim=1), F.softmax(logits_T, dim=1)).sum(1)
        loss_gt = self.criterion_gt(logits_S, labels)
        loss = self.alpha * loss_gt + (1.0 - self.alpha) * loss_kd
        weight = self.weight[labels.long()]
        loss = loss * weight
        loss = (loss * mask).sum() / (weight * mask).sum()
        return loss

class Similarity(nn.Module):
    def __init__(self, activation):
        super(Similarity, self).__init__()
        self.activation = activation
        self.softmax = nn.Sigmoid()

    def forward(self, x):
        m_batchsize, C, width, height = x.size()
        proj_query = x.view(m_batchsize, -1, width * height).permute(0, 2, 1)  # B X CX(N)
        proj_key = x.view(m_batchsize, -1, width * height)  # B X C x (*W*H)
        q_norm = proj_query.norm(2, dim=2)
        nm = torch.bmm(q_norm.view(m_batchsize, width * height, 1), q_norm.view(m_batchsize, 1, width * height))
        energy = torch.bmm(proj_query, proj_key)  # transpose check
        norm_energy = energy / nm
        # attention = self.softmax(norm_energy)  # BX (N) X (N)
        return norm_energy

class CriterionPairWise(nn.Module):
    def __init__(self):
        super(CriterionPairWise, self).__init__()
        self.attn = Similarity('relu')
        self.criterion = torch.nn.MSELoss()
        self.avgpool = nn.AvgPool2d(kernel_size=2, stride=2)

    def forward(self, feat_S, feat_T):
        assert feat_S.shape == feat_T.shape
        pool_feat_S = self.avgpool(feat_S)
        pool_feat_T = self.avgpool(feat_T)

        graph_S = self.attn(pool_feat_S)
        graph_T = self.attn(pool_feat_T)
        loss = self.criterion(graph_S, graph_T)
        return loss


if __name__ == '__main__':
   #test_myweight()
    # loss1 = nn.CrossEntropyLoss()
    # loss2 = CriterionSmoothingCE2()
    #
    # x = torch.randn(8,19,10,10)
    # label = torch.empty([8,10,10], dtype=torch.long).random_(19)
    #
    # out2 = loss2(x, label, smoothing=0.2)
    # out1 = loss1(x, label)
    #
    # print(out1)
    # print(out2)

    # a = np.asarray(
    #     [[
    #         [[1.5, 1], [8,5]],
    #         [[2.5, 4], [9,2]],
    #         [[1, 7], [3.5,3]]
    #     ]]
    # )
    #
    # b = np.asarray(
    #     [[
    #         [[1, 1], [8,5]],
    #         [[2, 4], [9.22,2]],
    #         [[1, 7], [3.5,0.7]]
    #     ]]
    # )
    # a = torch.from_numpy(a).float()
    # b = torch.from_numpy(b).float()
    #
    # #cri1 = CriterionL2KD(reduction='sum')
    # #cri2 = nn.MSELoss(reduction='sum')
    # cri1 = CriterionThresholdKd()
    #
    # loss1 = cri1(b,a, 0.7,1.0)
    # #loss2 = cri2(a, b)
    # print(loss1)
    # #print(loss2)

    # a = np.asarray(
    #     [[
    #         0.1,0.2,0.7
    #     ]
    #     ]
    # )
    #
    # b = np.asarray(
    #     [
    #         2
    #     ]
    # )
    #
    #
    #
    # a = torch.from_numpy(a).float()
    # b = torch.from_numpy(b).float()
    # print(a.shape)
    # a.requires_grad=True
    # print(b.shape)
    #
    # cri1 = CriterionSmoothingCE()
    #
    # loss1 = cri1(a,b)
    # #loss2 = cri2(a, b)
    # print(loss1)
    # loss1.backward()
    # #print(loss2)
    #test_CriterionNeutralKD()

    # a = np.asarray(
    #     [[
    #         -1,10000000000000000,10
    #     ]
    #     ]
    # )
    # a = torch.from_numpy(a).float()
    # print(a.shape)
    # log_prob = F.log_softmax(a, dim=1)
    # print(log_prob)
    # probs = F.softmax(a, dim=1).clamp(1e-10,1.0)
    # print(probs)
    # log_prob = probs.log()
    # print(log_prob)
    #test_CriterionSA2()
    # weight = np.asarray([
    #     0.6254756, 0.91231251, 0.83238672, 0.97848355, 0.99107175, 0.98707622,
    #     0.99854793, 0.99893004, 0.92090452, 0.97413724, 0.83252368, 0.9961591,
    #     0.99967596, 0.97227618, 0.98699205, 0.99476843, 0.99869174, 0.99965783,
    #     0.99992894])
    # a = weight[weight>0.9]
    # print(a.shape)
    test_maxsqure()


