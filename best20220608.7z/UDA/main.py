import random

import cv2

from datasets import Cityscapes
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
from config import config
import json
import argparse
import time
import os.path as osp
import torch
import torch.nn as nn

def print_hi(name):

    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.

class EvalTransform(object):
    def __init__(self, img_mean, img_std):
        self.img_mean = img_mean
        self.img_std = img_std

    def __call__(self, img, gt):
        img = normalize(img, self.img_mean, self.img_std)
        img = img.transpose(2,0,1) #C * H * W

        return img, gt

def test_trans():
    impth = '/media/wangyunnan/HP P500/deep learning/dataset/semantic segmentation/Cityscapes/leftImg8bit/train/aachen/aachen_000000_000019_leftImg8bit.png'
    lbpth = '/media/wangyunnan/HP P500/deep learning/dataset/semantic segmentation/Cityscapes/gtFine/train/aachen/aachen_000000_000019_gtFine_labelIds.png'

    #--------2------
    img = np.array(cv2.imread(
        impth, cv2.IMREAD_COLOR))
    img = img[:, :, ::-1]  # bgr2rgb
    gt = np.array(cv2.imread(
        lbpth, cv2.IMREAD_GRAYSCALE))
    data_transform = EvalTransform(config.img_mean, config.img_std)
    test2, _ = data_transform(img, gt)


    # #------1------
    img = Image.open(impth).convert('RGB')
    label = Image.open(lbpth)
    to_tensor = transforms.Compose([
         transforms.ToTensor(),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
     ])

    test1 = to_tensor(img)

    return test1, test2.round(4)

def get_name_list():
    with open('./cityscapes_info.json', 'r') as fr:
        labels_info = json.load(fr)
    name_list = {el['trainId']: el['name'] for el in labels_info}
    name_list.pop(255)
    name_list.pop(-1)

    return name_list

def get_color_map():
    with open('./cityscapes_info.json', 'r') as fr:
        labels_info = json.load(fr)
    color = {el['trainId']: el['color'] for el in labels_info}
    color.pop(255)
    color.pop(-1)
    return  color


def generate_confusion_matrix(gts, preds):
    mask = (gts >= 0) &  (gts < 2)
    index = gts[mask].astype('int') * 2 + preds[mask].astype('int')
    hist = np.bincount(index, minlength=2**2)
    confusion_matrix = hist.reshape(2, 2)

    return confusion_matrix
def test_maxtrx():
    label =np.asarray([0,0,0,0,0,0,1,1,1,1])
    pred = np.asarray([0,0,0,0,0,1,1,1,1,1])

    mat = generate_confusion_matrix(label, pred)
    #mat = np.asarray([[  43466. , 11238.],[  11238.,2582058.]])
    radio = np.sum(mat, axis=1) / np.sum(mat)
    MPA = np.diag(mat) / mat.sum(axis=1)
    print(MPA)
    MPA = np.nanmean(MPA) * 100
    MPA = MPA.round(4)
    print(MPA)
    return


def parse_args():
    parser = argparse.ArgumentParser()

    """Save Seting"""
    time_cur = time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime())
    save_path = osp.join('/home/wangyunnan/code/PycharmProjects/BiSeNet/save', time_cur)
    parser.add_argument('--save_root', default=save_path, type=str, help='the root path of saved files')
    parser.add_argument('--snapshot_iter', default=1, type=int, help='the interval of saving ckpt')

    """Dataset Setting"""
    dataset_root = '/media/wangyunnan/HP P500/deep learning/dataset/semantic segmentation/Cityscapes'
    trainval_list = './datasets/cityscapes/list/trainval.txt'
    train_list = './datasets/cityscapes/list/train.txt'
    val_list = './datasets/cityscapes/list/valtest.txt'
    test_list = './datasets/cityscapes/list/test.txt'
    parser.add_argument('--dataset_root', default=dataset_root, type=str, help='the root of dataset')
    parser.add_argument('--train_list', default=train_list, type=str, help='the path of training list')
    parser.add_argument('--val_list', default=val_list, type=str, help='the path of validation list')
    parser.add_argument('--test_list', default=test_list, type=str, help='the path of testing list')
    parser.add_argument('--trainval_list', default=trainval_list, type=str, help='the path of training validation list')

    """Image Setting"""
    parser.add_argument('--num_classes', default=19, type=int, help='the number of class')
    parser.add_argument('--ignore_label', default=255, type=int, help='the ignored label')
    parser.add_argument('--img_mean', default=[0.485, 0.456, 0.406], type=list, help='the mean of images')
    parser.add_argument('--img_std ', default=[0.229, 0.224, 0.225], type=list, help='the std of images')
    parser.add_argument('--crop_size', default=[1024, 1024], type=list, help='the crop of imaghes')

    """Train Setting"""
    parser.add_argument('--lr', default=1e-2, type=float, help='the learning rate')
    parser.add_argument('--lr_power', default=0.9, type=float, help='the poly power of learning rate')
    parser.add_argument('--momentum', default=0.9, type=float, help='the parameter of momentum')
    parser.add_argument('--weight_decay', default=5e-4, type=float, help='the parameter of weight decay')
    parser.add_argument('--batch_size', default=2, type=int, help='the batch size per gpu')
    parser.add_argument('--nepochs', default=2, type=int, help='the number of epochs')
    parser.add_argument('--niters_per_epoch', default=50, type=int, help='the number of iteration per epoch')
    parser.add_argument('--num_workers', default=6, type=int, help='the number of dataloader workers')
    parser.add_argument('--train_scale', default=[0.75, 1, 1.25, 1.5, 1.75, 2.0], type=list, help='the scale of images')
    parser.add_argument('--num_gpus', default=torch.cuda.device_count(), type=int, help='the number of gpus')
    parser.add_argument('--local_rank', default=-1, type=int, help='the node rank for distributed training')
    parser.add_argument('--seed', default=12345, type=int, help='random seed')

    """Eval Setting"""
    parser.add_argument('--eval_stride_rate', default=5 / 6., type=float, help='the sliding stride rate of evaluation')
    parser.add_argument('--eval_scale', default=[1, ], type=list, help='the image scale of evaluation')
    # multi scales: 0.5, 0.75, 1, 1.25, 1.5, 1.75
    parser.add_argument('--eval_flip', default=False, type=bool, help='the flip option of evaluation')
    # True if use the ms_flip strategy
    parser.add_argument('--eval_crop_size', default=1024, type=int, help='the node rank for distributed training')

    args = parser.parse_args()
    return args
import os
from PIL import Image
from PIL import ImageFilter

def test_PIL():
    img = Image.open('/media/wangyunnan/Data/datasets/GTAV/images/train/00004.png').convert('RGB')
    img = np.array(img)
    img = img[:,:,::-1]
    cv2.imshow('test',img)
    cv2.waitKey()
    img = Image.open('/media/wangyunnan/Data/datasets/GTAV/images/train/00004.png').convert('RGB')
    img = img.filter(ImageFilter.GaussianBlur(radius=0.99))
    img = np.array(img)
    img = img[:,:,::-1]
    cv2.imshow('test',img)
    cv2.waitKey()

def test_logic():
    a = np.ones((2,2)).astype(np.int)
    b = np.array([[1,0],[0,1]])
    index = (a == 1) | (b == 1)
    print(index)

def test_tensor():
    print(torch.tensor(0).item())

def test_shuffle():
    class_list = list(range(19))
    random.shuffle(class_list)
    for i in class_list:
        print(i)
    print(class_list)
    np.random.shuffle(class_list)
    print(class_list)

from datasets.cityscapes import Cityscapes
from dataloader import get_city_train_loader,get_gtav_train_loader
from network.deeplab import DeeplabV2
import torch


def reset_bn(module):
    if issubclass(module.__class__, nn.modules.batchnorm._BatchNorm):
        module.running_mean.zero_()
        module.running_var.fill_(1)
        #print(module.weight)
        #print(module.num_batches_tracked)
        # for i in module.parameters():
        #     i.requires_grad = False # freeze

def freeze_bn():
    model = DeeplabV2(pretrained=False)
    model.load_state_dict(torch.load('./save/teacher_init1_447168.pth'))
    model.cuda()
    model.train()
    #model.reset_bn()
    model.apply(reset_bn)

    dl = get_city_train_loader()
    for idx, batch in enumerate(dl):
        img, _ = batch
        img = img.cuda()
        with torch.no_grad():
            model(img)
        print(idx)

    model.eval()
    #torch.save(model.state_dict(), './save/epoch-10_freeze.pth')

    #dict = torch.load('./save/epoch-12_freeze.pth')
    #print(type(dict))

    # for k, v in dict.items():
    #     if 'bn' in k:
    #         print(k , v)

def replace_bn():
    origin_dict = torch.load('./save/deeplab_init.pth')
    freezed_dict = torch.load('./save/42_2451.pth')

    new_params =torch.load('./save/42_2451.pth').copy()
    for i in origin_dict:
        i_parts = i.split('.')
        if not i_parts[1] == 'layer5':
            new_params['.'.join(i_parts[1:])] = origin_dict[i]

    origin_dict=new_params
    count = 0
    for k, v in origin_dict.items():
        if 'bn' in k:
            origin_dict[k] = freezed_dict[k]
            count+=1
    print(count)

    torch.save(origin_dict, './save/deeplab_init_freezed.pth')

import sys
from config import config
from tqdm import tqdm
def ada_bn():
    model = DeeplabV2(pretrained=False)
    model.load_state_dict(torch.load('./save/teacher_init1_40_8702.pth'))
    #train_dict = torch.load('./save/teacher_init1_40_8702.pth')
    #origin_dict = torch.load('./save/deeplab_init.pth')
    model.apply(reset_bn)

    source_loader = get_gtav_train_loader()
    target_loader = get_city_train_loader()
    source_loader_iter = iter(source_loader)
    target_loader_iter = iter(target_loader)
    best_mIoU = 0

    for epoch in range(0, config.num_epochs):
        current_epoch = epoch

        pbar = tqdm(range(config.iters_per_epoch), file=sys.stdout)
        for idx in pbar:
            with torch.no_grad():
                source_img, _ = next(source_loader_iter)
                source_img = source_img.cuda()
                model(source_img)

                target_img, _ = next(target_loader_iter)
                target_img = target_img.cuda()
                model(target_img)

        # Save checkpoint
            save_path = osp.join(config.ckpt_path, 'epoch-{}.pth'.format(config.current_epoch))
            torch.save(model.state_dict(), save_path)
            logger.warning('Saving checkpoint to {}'.format(save_path))

            # Evaluate one epoch
            mIoU = agent_eval.start(save_path)
            if mIoU > best_mIoU:
                best_mIoU = mIoU
                self.best_epoch = self.current_epoch
                self.logger.warning('New best mIoU {} is at epoch-{}'.format(self.best_mIoU, self.best_epoch))
            else:
                self.logger.warning('The best mIoU {} is still at epoch-{}'.format(self.best_mIoU, self.best_epoch))
            self.writer.add_scalar('train/city_mIoU', mIoU, self.current_epoch)

def set_bn():
    origin_dict = torch.load('./save/deeplab_init.pth')
    model = DeeplabV2(pretrained=True)
    model.apply(reset_bn)
    #print(origin_dict)
    # for k, v in origin_dict.items():
    #     if 'bn' in k :
    #         print(k)
import torch.nn.functional as F
def block_replace(source_img, target_img, source_gt, target_logits,block_size=(128,128)):
    assert source_img.shape == target_img.shape
    h, w = target_img.shape[:2]
    crop_h, crop_w = block_size[0], block_size[1]

    source_gt[source_gt==255] = 0
    one_hot = torch.zeros(source_gt[0], 19, source_img[1], source_gt[2])
    one_hot = one_hot.scatter_(1, source_gt, 1)
    probs = F.softmax(target_logits, dim=1)

    if h > crop_h:
        x = random.randint(0, h - crop_h + 1)
        target_img[x:x + crop_h, :, :] = target_img[x:x + crop_h, :, :]
        probs[:,:,x:x + crop_h, :] = one_hot[:,:,x:x + crop_h, :]

    if w > crop_w:
        x = random.randint(0, w - crop_w + 1)
        target_img[:, x:x + crop_w, :] = source_img[:, x:x + crop_w, :]
        probs[:,:,:, x: x + crop_w] = one_hot[:,:,:, x:x + crop_w]

    return target_img, probs

def test_flip():
    img = cv2.imread('./save/00003_o.png')
    img = img.transpose((2, 0, 1))

    x = 0
    y = 0
    w = x + 500
    h = y + 250
    img = torch.from_numpy(np.ascontiguousarray(img))

    img = img.unsqueeze(0).float()
    img = F.interpolate(img, (400,800), mode='bilinear', align_corners=True)
    img = img[:,:,y:h,x:w]
    print(img.shape)
    img = img.squeeze(0)

    img = img.numpy()
    img = np.uint8(img)
    img = img.transpose((1, 2, 0))
    cv2.imshow('t',img)
    cv2.waitKey()
    print(img.shape)

def test_weight():
    weight = torch.load('./save/weights/city_train_pseudo_weight.pth')
    ignore = torch.FloatTensor([0])
    weight = torch.cat([weight,ignore])
    #weight = weight / weight.sum()
    print(weight)

    weight = torch.load('./save/weights/gtav_trainval_fine_weight_inv.pth')
    # weight = weight / weight.sum()
    print(weight)

def getAffineTransform(src, dst, size):
    H, W = size
    T = np.array([
            [2 / W, 0, -1],
            [0, 2 / H, -1],
            [0, 0, 1]
    ])
    M = cv2.getAffineTransform(src, dst)
    M = np.vstack((M, np.asarray([[0, 0, 1]])))
    theta = np.linalg.inv(T @ M @ np.linalg.inv(T))
    theta = torch.from_numpy(theta[:2, :]).unsqueeze(0).type(torch.float32)
    return theta

def getAffineMatrix(M, size):
    H, W = size
    T = np.array([[2 / W, 0, -1], [0, 2 / H, -1], [0, 0, 1]])
    M = np.vstack((M, np.asarray([[0, 0, 1]])))
    theta = np.linalg.inv(T @ M @ np.linalg.inv(T))
    theta = torch.from_numpy(theta)
    return theta

def random_wrapAffine(tensor):
    n, c, h, w = tensor.shape
    mask = torch.ones((n,1,h,w)).float() * 255
    M = np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float)
    theta = getAffineMatrix(M, (h, w))
    inv_theta = getAffineMatrix(M, (h, w))
    inv_set =[]

    # ShearX
    if random.random() < 0.5:
        angleSX = random.uniform(-10, 10) / 180 * np.pi
        MSX = np.array([[1, np.tan(angleSX), 0], [0, 1, 0]], dtype=np.float)
        thetaSX = getAffineMatrix(MSX, (h, w))
        inv_MSX = np.array([[1, np.tan(-angleSX), 0], [0, 1, 0]], dtype=np.float)
        inv_thetaSX = getAffineMatrix(inv_MSX, (h, w))
        theta = torch.mm(theta, thetaSX)
        inv_set.append(inv_thetaSX)

    # ShearY
    if random.random() < 0.5:
        angleSY = random.uniform(-10, 10) / 180 * np.pi
        MSY = np.array([[1, 0, 0],[np.tan(angleSY), 1, 0]], dtype=np.float)
        thetaSY = getAffineMatrix(MSY, (h, w))
        inv_MSY = np.array([[1, 0, 0],[np.tan(-angleSY), 1, 0]], dtype=np.float)
        inv_thetaSY = getAffineMatrix(inv_MSY, (h, w))
        theta = torch.mm(theta, thetaSY)
        inv_set.append(inv_thetaSY)

    # Rotate
    if random.random() < 0.5:
        angleR = random.uniform(-10, 10) / 180 * np.pi
        MR = np.array([[np.cos(angleR), -np.sin(angleR), 0],[np.sin(angleR), np.cos(angleR), 0],[0, 0, 1]], dtype=np.float)
        thetaR = torch.from_numpy(MR)
        inv_MR = np.array([[np.cos(-angleR), -np.sin(-angleR), 0],[np.sin(-angleR), np.cos(-angleR), 0],[0, 0, 1]], dtype=np.float)
        inv_thetaR = torch.from_numpy(inv_MR)
        theta = torch.mm(theta, thetaR)
        inv_set.append(inv_thetaR)

    # TranslateX
    if random.random() < 0.5:
        translateX = random.uniform(-0.5, 0.5)
        MTX = np.array([[1, 0, translateX], [0, 1, 0],[0, 0, 1]]).astype(np.float)
        thetaTX = torch.from_numpy(MTX)
        inv_MTX = np.array([[1, 0, -translateX], [0, 1, 0],[0, 0, 1]]).astype(np.float)
        inv_thetaTX = torch.from_numpy(inv_MTX)
        theta = torch.mm(theta, thetaTX)
        inv_set.append(inv_thetaTX)

    # TranslateY
    if random.random() < 0.5:
        translateY = random.uniform(-0.5, 0.5)
        MTY = np.array([[1, 0, 0], [0, 1, translateY],[0, 0, 1]]).astype(np.float)
        thetaTY = torch.from_numpy(MTY)
        inv_MTY = np.array([[1, 0, 0], [0, 1, -translateY],[0, 0, 1]]).astype(np.float)
        inv_thetaTY = torch.from_numpy(inv_MTY)
        theta = torch.mm(theta, thetaTY)
        inv_set.append(inv_thetaTY)

    for m in reversed(inv_set):
        inv_theta = torch.mm(inv_theta, m)

    print(theta)
    theta = theta[:2, :].expand(n,2,3).type(torch.float32)
    inv_theta = inv_theta[:2, :].expand(n,2,3).type(torch.float32)
    print(theta)

    grid = F.affine_grid(theta, tensor.size(), align_corners=True)
    tensor = F.grid_sample(tensor, grid, mode='bilinear', align_corners=True)
    mask = F.grid_sample(mask, grid, mode='bilinear', align_corners=True)

    return tensor, mask, inv_theta

def inv_wrapAffine(tensor, inv_theta):
    grid = F.affine_grid(inv_theta, tensor.size(), align_corners=True)
    tensor = F.grid_sample(tensor, grid, mode='bilinear', align_corners=True)
    return tensor

def tensor2cv(tensor):
    tensor = tensor.squeeze(0)
    tensor = tensor.numpy()
    tensor = np.uint8(tensor)
    tensor = tensor.transpose((1, 2, 0))
    return tensor

def test_transfer():
    img = cv2.imread('./save/00003.png')
    img = img.transpose((2, 0, 1))
    img = torch.from_numpy(np.ascontiguousarray(img))

    img = img.unsqueeze(0).float()

    img, mask, inv_theta= random_wrapAffine(img)
    img = inv_wrapAffine(img, inv_theta)
    mask = inv_wrapAffine(mask, inv_theta)

    img = tensor2cv(img)
    cv2.imwrite('./save/trans_img.png', img)
    cv2.imshow('trans_img',img)
    cv2.waitKey()

    mask = tensor2cv(mask)
    cv2.imwrite('./save/trans_mask.png', mask)
    cv2.imshow('trans_mask',mask)
    cv2.waitKey()

def test_expand():
    a = torch.Tensor([[1,2,3],[4,5,6]])
    print(a.shape)
    a = a.expand(4,2,3)
    print(a.shape)
    print(a)
def test_mask():
    a = torch.Tensor([[1, 2, 3], [4, 5, 6]])
    b= torch.ones_like(a)
    c = torch.stack((b,a),dim=0)
    print(c.shape)

def test_sort():
    arr1 = torch.Tensor([98, 59, 78])
    arr2 = torch.Tensor([98, 59, 78])
    arr2, index = torch.sort(arr2, descending=True)
    print(arr2)
    print(index)
    arr1 = arr1[index]
    print(arr1)



if __name__ == '__main__':
    #freeze_bn()
    #replace_bn()
    #a = np.asarray([1,1])
    #print(a/(0+1e-6))
    #ada_bn()
    # a = np.ones(1)/np.zeros(1)
    # print(a[0])
    # print(np.isnan(a[0]))
    # test_roate()
    #test_transfer()
    #test_weight()
    test_sort()






