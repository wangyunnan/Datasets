import cv2
import sys
import os
import os.path as osp
import numpy as np
import torch
from PIL import Image
import torch.nn.functional as F

from network.deeplab import DeeplabV2
from utils.img_utils import normalize
from config import config

#Cityscapes Class Color Map (255 is change to 19)
color_map = {0: [128, 64, 128], 1: [244, 35, 232], 2: [70, 70, 70], 3: [102, 102, 156],
             4: [190, 153, 153], 5: [153, 153, 153], 6: [250, 170, 30], 7: [220, 220, 0],
             8: [107, 142, 35], 9: [152, 251, 152], 10: [70, 130, 180], 11: [220, 20, 60],
             12: [255, 0, 0], 13: [0, 0, 142], 14: [0, 0, 70], 15: [0, 60, 100], 16: [0, 80, 100],
             17: [0, 0, 230], 18: [119, 11, 32], 19: [0, 0, 0]}

class Visualizer(object):
    def __init__(self, ckpt_path='', save_path=''):
        #Init setting
        self.ckpt_path = ckpt_path
        self.save_path = save_path

        # Establish save path
        if not osp.exists(self.save_path):
            os.makedirs(self.save_path)

        self.save_names = []
        self.list_path = config.city_train_list
        self.root = config.city_root

        # Exit if path do not exist
        try:
            if not osp.exists(self.root): raise ValueError
        except ValueError :
            print('Data root do not exist!')
            sys.exit(0)

        self.num_classes = config.num_classes
        self.color_list = []
        self.bgr_mean = np.array((104.00698793, 116.66876762, 122.67891434), dtype=np.float32)

        for i in range(self.num_classes + 1):
            self.color_list.append(color_map[i])

        with open(self.list_path, 'r') as fr:
            self.files = fr.readlines()

        # Model setting
        self.model = DeeplabV2(num_classes=self.num_classes, pretrained=False)
        self.model.load_state_dict(torch.load(self.ckpt_path, map_location='cuda:0'))
        print('Checkpoint loaded successfully!')
        self.model.cuda()
        self.model.eval()


    def visual_images(self, index):
        names = self.files[index[0]]
        index.remove(index[0])
        self.save_names = []
        imgs, gts = self.processing_files(names)

        for i in index:
            names = self.files[i]
            img, gt = self.processing_files(names)
            imgs = torch.cat((imgs,img), dim=0)
            gts = np.concatenate((gts, gt), axis=0)

        print(imgs.shape)
        with torch.no_grad():
            prob = self.whole_eval(imgs)
        sorce_map = prob.copy()
        pred = np.argmax(prob, axis=1)
        mask = (gts == 255)
        pred[mask] = self.num_classes

        color_list = np.asarray(self.color_list)
        show = color_list[pred.astype('int')]

        for i, (img, sorce) in enumerate(zip(show, sorce_map)):
            img = np.uint8(img)
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            cv2.imshow('visualization', img)
            cv2.waitKey(0)
            cv2.imwrite(osp.join(self.save_path, self.save_names[i]), img)

    def processing_files(self, names):
        img_name, gt_name = names.strip().split('\t')
        self.save_names.append(img_name.split('/')[-1].replace('_leftImg8bit.png','_pseudoLabeledId.png'))
        print(img_name)

        img = Image.open(osp.join(self.root, img_name)).convert('RGB')
        gt = Image.open(osp.join(self.root, gt_name))

        img = np.asarray(img)[:, :, ::-1] #change to bgr
        gt = np.asarray(gt)

        img = img.astype(np.float32) - self.bgr_mean
        img = img.transpose((2, 0, 1))

        # To tensor
        img = torch.from_numpy(np.ascontiguousarray(img)).float()

        img = img.unsqueeze(0).cuda()
        gt = gt.astype(np.int64)[np.newaxis, :]

        return img, gt

    def whole_eval(self, imgs):
        probs = self.inference(imgs)
        probs = probs.detach().cpu().numpy()
        return probs

    def inference(self, img):
        out = self.model(img)
        prob = F.softmax(out, 1)
        return prob


if __name__ == '__main__':

    # Visualization
    agent_visual = Visualizer(ckpt_path='./save/sac2.pth', save_path=osp.join(config.save_root, 'visual'))
    agent_visual.visual_images([0])