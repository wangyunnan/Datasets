from torch.utils.data import DataLoader

from config import config
from datasets.gtav import GTAV
from datasets.cityscapes import Cityscapes
from datasets.augmentations import *

def get_gtav_augmentations():
    return Compose(
        [
            RandomMirror(p=0.5),
            ColorJitter(brightness=0.5, contrast=0.5, saturation=0.5),
            #RandomGauss(p=0.5),
            RandomScale(scale_range=config.scale_range),
            RandomCrop(config.crop_size)
        ]
    )

def get_city_augmentations():
    return Compose(
        [
            RandomMirror(p=0.5),
            ColorJitter(brightness=0.5, contrast=0.5, saturation=0.5),
            RandomGauss(p=0.5),
            RandomGray(p=0.2),
            RandomScale(scale_range=config.scale_range),
            RandomCrop(config.crop_size)
        ]
    )

def get_gtav_train_loader():
    data_setting = {
        'root': config.gtav_root,
        'train_list': config.gtav_train_list
    }

    augmentations = get_gtav_augmentations()
    train_dataset = GTAV(
        data_setting, #gtav only get train data!
        config.gta_mode,
        augmentations,
        config.iters_per_epoch * config.batch_size * config.num_epochs
    )

    train_loader = DataLoader(train_dataset,
                              batch_size=config.batch_size,
                              num_workers=config.num_workers,
                              drop_last=True,
                              shuffle=True,
                              pin_memory=True)
    return train_loader

def get_city_train_loader():
    data_setting = {
        'root': config.city_root,
        'train_list': config.city_train_list,
        'val_list': config.city_eval_list
    }

    augmentations = get_city_augmentations()
    train_dataset = Cityscapes(
        data_setting=data_setting,
        mode="train",
        augmentations=augmentations,
        file_length=config.iters_per_epoch * config.batch_size * config.num_epochs
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
        drop_last=True,
        shuffle=True,
        pin_memory=True
    )
    return train_loader


def get_eval_loader():
    data_setting = {
        'root': config.city_root,
        'train_list': config.city_train_list,
        'val_list': config.city_eval_list
    }

    eval_dataset = Cityscapes(
        data_setting=data_setting,
        mode="val",
        augmentations=None
    )

    eval_loader = DataLoader(
        eval_dataset,
        batch_size=10,
        num_workers=config.num_workers,
        drop_last=False,
        shuffle=False
    )
    return eval_loader

def get_pseudo_label_test_loader():
    data_setting = {
        'root': config.city_root,
        'train_list': config.city_train_list,
        'val_list': config.city_eval_list.replace("val.txt", "val.txt")
    }

    eval_dataset = Cityscapes(
        data_setting,
        "val",
        None
    )

    eval_loader = DataLoader(
        eval_dataset,
        batch_size=2,
        num_workers=config.num_workers,
        drop_last=False,
        shuffle=False
    )
    return eval_loader

def get_pseudo_label_loader():
    data_setting = {
        'root': config.city_root,
        'train_list': config.city_train_list,
        'val_list': config.city_train_list
    }

    pseudo_label_dataset = Cityscapes(
        data_setting,
        "val",
        None
    )

    pseudo_label_loader = DataLoader(
        pseudo_label_dataset,
        batch_size=2,
        num_workers=config.num_workers,
        drop_last=False,
        shuffle=False
    )
    return pseudo_label_loader

if __name__ == '__main__':
    source_loader = get_gtav_train_loader()
    source_loader_iter = iter(source_loader)
    from  tqdm import tqdm
    import sys
    pbar = tqdm(range(200000), file=sys.stdout)
    for idx in pbar:
        img,_ = next(source_loader_iter)
